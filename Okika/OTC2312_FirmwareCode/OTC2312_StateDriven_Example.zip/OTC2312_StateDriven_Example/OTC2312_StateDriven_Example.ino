#include <SPI.h>
#include "FPAA_Config.h"

#define SELb 10  // SPI CS Pin

void resetConfig(){
  // State Reconfiguration - software reset
  byte msg[9] = {0, 0, 0, 0, 0, 213, 1, 111, 0};

  digitalWrite(SELb, LOW);
  for(int i=0; i<9; i++){  
    SPI.transfer(msg[i]);
  }
  digitalWrite(SELb, HIGH);
}

/**
* @brief Send Primary Configuration to FPAA over SPI
* @param none
* @return none
*/
void sendConfig(){
  // Send data over SPI
  digitalWrite(SELb, LOW);
  //delayMicroseconds(10);  
  for(int i=0; i<(sizeof(config_data)); i++){
    SPI.transfer(config_data[i]);
  }
  digitalWrite(SELb, HIGH);
  //delayMicroseconds(10);
}

/**
* @brief Initialize SPI and CS pin
* @param none
* @return none
*/
void setup() {
  Serial.begin(115200);

  // Init CS GPIO
  pinMode(SELb, OUTPUT); // set the SS pin as an output

  // Initialize SPI
  SPI.begin();
  SPI.setBitOrder(MSBFIRST);
  SPI.setDataMode(SPI_MODE3);
  SPI.setClockDivider(SPI_CLOCK_DIV2);

  delay(50);  // Allow SPI to stabilize
  
  // Send FPAA Primary Configuration
  resetConfig(); // software reset
  sendConfig();
}

void loop() {
  // idle
}
