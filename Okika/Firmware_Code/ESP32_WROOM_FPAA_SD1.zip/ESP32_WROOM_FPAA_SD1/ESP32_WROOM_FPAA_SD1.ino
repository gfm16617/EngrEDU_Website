#include <Arduino.h>
#include <SPI.h>
#include "FPAA_StateDriven.h"

//============== FPAA PINS =============//
#define SELb      18
#define PIN_MOSI  17
#define PIN_MISO  16
#define PIN_SCK   5
#define PIN_PORb  27

//============== DYNAMIC CONFIGURATION VARIABLES =============//
const int num_configs = 30;  // number of states
const int size_data = sizeof(state_1); //sizeof(data) + 1 - since config arrays have the same size this will be consisten 
const byte *reconfig_data[num_configs] = { state_1, state_2, state_3, state_4, state_5, 
                                           state_6, state_7, state_8, state_9, state_10, state_11,
                                           state_12, state_13, state_14, state_15, state_16, state_17,
                                           state_18, state_19, state_20, state_21, state_22, state_23,
                                           state_24, state_25, state_26, state_27, state_28, state_29, 
                                           state_30};

void hardwareReset(){
  digitalWrite(PIN_PORb, LOW);
  delay(20); // 20ms
  digitalWrite(PIN_PORb, HIGH);
  delay(100); // 100ms
}

void softwareReset(){
  // State Reconfiguration
  byte msg[9] = {0, 0, 0, 0, 0, 213, 1, 111, 0};

  digitalWrite(SELb, LOW);
  for(int i=0; i<9; i++){  
    SPI.transfer(msg[i]);
  }
  //SPI.endTransaction();
  digitalWrite(SELb, HIGH);
}

void primaryConfig(){
  // Send Configuration
  digitalWrite(SELb, LOW);

  for(int i=0; i<(sizeof(primary_config)); i++){
    SPI.transfer(primary_config[i]);
  }
  //SPI.endTransaction();
  digitalWrite(SELb, HIGH);
}

void setup() {
  // Initialize Serial
  Serial.begin(57600);

  // Initialize GPIO
  pinMode(PIN_PORb, OUTPUT); // hardware reset pin
  digitalWrite(PIN_PORb, HIGH);

  pinMode(SELb, OUTPUT); // set the SS pin as an output
  digitalWrite(SELb, HIGH);

  // Init SPI
  //SPI.begin();
  SPI.begin(PIN_SCK, PIN_MISO, PIN_MOSI, SELb);
  SPI.setBitOrder(MSBFIRST);
  SPI.setDataMode(SPI_MODE3);
  SPI.setClockDivider(SPI_CLOCK_DIV2);

  delay(500);  // Allow SPI to stabilize
  
  // Program FPAA
  //hardwareReset();
  softwareReset();
  primaryConfig(); // Send FPAA Primary Configuration

}

void loop() {
  dynamicReconfig();
}

void dynamicReconfig(){
  for(int i=0; i<num_configs; i++){
    // Send Configuration
    digitalWrite(SELb, LOW);
    for(int j=0; j<size_data; j++){
      SPI.transfer(reconfig_data[i][j]);
    }
    //SPI.endTransaction();
    digitalWrite(SELb, HIGH);
    delay(100);
  }
}

