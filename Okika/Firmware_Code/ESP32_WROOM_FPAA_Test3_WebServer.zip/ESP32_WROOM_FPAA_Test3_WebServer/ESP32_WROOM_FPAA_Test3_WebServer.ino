#include <Arduino.h>
#include <SPI.h>
#include <WiFi.h>
#include <AsyncTCP.h>
#include <ESPAsyncWebServer.h>
#include "FPAA_StateDriven.h"

//============== ACCESS POINT CREDENTIALS =============//
const char* ap_ssid     = "FPAA-Controller";
const char* ap_password = "";

//============== FPAA PINS =============//
#define SELb      18
#define PIN_MOSI  17
#define PIN_MISO  16
#define PIN_SCK   5
#define PIN_PORb  27

//============== SPI VARIABLES =============//
#define SPI_SPEED 4000000

//============== DYNAMIC CONFIGURATION VARIABLES =============//
const int num_configs = 12;
const int size_data   = 15;
const byte *tunning_freq[num_configs] = {
  freq_C1, freq_C2, freq_C3, freq_C4,  freq_C5,  freq_C6,
  freq_C7, freq_C8, freq_C9, freq_C10, freq_C11, freq_C12
};

const char* freq_labels[num_configs] = {
  "C1", "C2", "C3", "C4",  "C5",  "C6",
  "C7", "C8", "C9", "C10", "C11", "C12"
};

AsyncWebServer server(80);
int currentConfig = -1;

//============================================================//
//                      FPAA FUNCTIONS                        //
//============================================================//

void softwareReset() {
  byte msg[9] = {0, 0, 0, 0, 0, 213, 1, 111, 0};
  digitalWrite(SELb, LOW);
  for (int i = 0; i < 9; i++) SPI.transfer(msg[i]);
  digitalWrite(SELb, HIGH);
}

void primaryConfig() {
  digitalWrite(SELb, LOW);
  for (size_t i = 0; i < sizeof(primary_config); i++) SPI.transfer(primary_config[i]);
  digitalWrite(SELb, HIGH);
}

void sendDynamicConfig(int index) {
  if (index < 0 || index >= num_configs) return;
  digitalWrite(SELb, LOW);
  for (int j = 0; j < size_data; j++) SPI.transfer(tunning_freq[index][j]);
  digitalWrite(SELb, HIGH);
  currentConfig = index;
}

//============================================================//
//                      WEB SERVER HANDLERS                   //
//============================================================//

// Stored as a constant — built once, never rebuilt on each request
const char PAGE_HTML[] PROGMEM = R"rawhtml(
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>FPAA Frequency Selector</title>
  <style>
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body {
      font-family: 'Segoe UI', sans-serif;
      background: #1a1a2e;
      color: #eee;
      display: flex;
      flex-direction: column;
      align-items: center;
      padding: 40px 20px;
      min-height: 100vh;
    }
    h1 { font-size: 1.8rem; margin-bottom: 8px; color: #e94560; }
    .subtitle { font-size: 0.9rem; color: #888; margin-bottom: 32px; }
    .grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(100px, 1fr));
      gap: 12px;
      width: 100%;
      max-width: 560px;
    }
    .freq-btn {
      padding: 18px 10px;
      border: 2px solid #e94560;
      border-radius: 10px;
      background: transparent;
      color: #e94560;
      font-size: 1.1rem;
      font-weight: bold;
      cursor: pointer;
      transition: all 0.2s;
    }
    .freq-btn:hover  { background: #e94560; color: #fff; }
    .freq-btn.active { background: #e94560; color: #fff; box-shadow: 0 0 12px #e9456088; }
    .status {
      margin-top: 32px;
      padding: 14px 28px;
      background: #16213e;
      border-radius: 10px;
      font-size: 1rem;
      color: #aaa;
      text-align: center;
      min-width: 260px;
    }
    .status span { color: #e94560; font-weight: bold; }
  </style>
</head>
<body>
  <h1>FPAA Frequency Selector</h1>
  <p class="subtitle">Select a tuning frequency to send to the FPAA</p>
  <div class="grid">
    <button class='freq-btn' onclick="selectFreq(0)">C1</button>
    <button class='freq-btn' onclick="selectFreq(1)">C2</button>
    <button class='freq-btn' onclick="selectFreq(2)">C3</button>
    <button class='freq-btn' onclick="selectFreq(3)">C4</button>
    <button class='freq-btn' onclick="selectFreq(4)">C5</button>
    <button class='freq-btn' onclick="selectFreq(5)">C6</button>
    <button class='freq-btn' onclick="selectFreq(6)">C7</button>
    <button class='freq-btn' onclick="selectFreq(7)">C8</button>
    <button class='freq-btn' onclick="selectFreq(8)">C9</button>
    <button class='freq-btn' onclick="selectFreq(9)">C10</button>
    <button class='freq-btn' onclick="selectFreq(10)">C11</button>
    <button class='freq-btn' onclick="selectFreq(11)">C12</button>
  </div>
  <div class="status" id="status">No frequency selected yet.</div>
  <script>
    function selectFreq(index) {
      fetch('/set?freq=' + index)
        .then(r => r.text())
        .then(msg => {
          document.getElementById('status').innerHTML = msg;
          document.querySelectorAll('.freq-btn').forEach((b, i) => {
            b.classList.toggle('active', i === index);
          });
        })
        .catch(() => {
          document.getElementById('status').textContent = 'Error communicating with ESP32.';
        });
    }
  </script>
</body>
</html>
)rawhtml";

//============================================================//
//                         SETUP                             //
//============================================================//

void setup() {
  pinMode(PIN_PORb, OUTPUT);
  digitalWrite(PIN_PORb, HIGH);
  pinMode(SELb, OUTPUT);
  digitalWrite(SELb, HIGH);

  SPI.begin(PIN_SCK, PIN_MISO, PIN_MOSI, SELb);
  SPI.setBitOrder(MSBFIRST);
  SPI.setDataMode(SPI_MODE3);
  SPI.setClockDivider(SPI_CLOCK_DIV2);
  delay(500);

  softwareReset();
  primaryConfig();

  WiFi.softAP(ap_ssid, ap_password);

  server.on("/", HTTP_GET, [](AsyncWebServerRequest *request) {
    request->send_P(200, "text/html", PAGE_HTML);
  });

  server.on("/set", HTTP_GET, [](AsyncWebServerRequest *request) {
    if (!request->hasParam("freq")) {
      request->send(400, "text/plain", "Missing 'freq' parameter.");
      return;
    }

    int idx = request->getParam("freq")->value().toInt();

    if (idx < 0 || idx >= num_configs) {
      request->send(400, "text/plain", "Invalid frequency index.");
      return;
    }

    sendDynamicConfig(idx);

    String response = "Active config: <span>" + String(freq_labels[idx]) + "</span>";
    request->send(200, "text/html", response);
  });

  server.onNotFound([](AsyncWebServerRequest *request) {
    request->send(404, "text/plain", "404 Not Found");
  });

  server.begin();
}

//============================================================//
//                          LOOP                             //
//============================================================//

void loop() {
  // Nothing here — ESPAsyncWebServer handles everything on interrupts
}