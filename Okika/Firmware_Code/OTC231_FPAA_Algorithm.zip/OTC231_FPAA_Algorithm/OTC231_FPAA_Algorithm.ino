#include <Arduino.h>
#include <SPI.h>
#include "ApiCode.h"
#include "CAMCode.h"

// ================================================================
// Pin definitions — identical to the working state-driven code
// ================================================================
#define SELb      10  // D10 → FPAA nCS    (hardware SS)
#define PIN_PORb  6   // D6  → FPAA nRESET

#define POT_SAMPLES 8  // number of samples to average (reduces jitter)

/*
void hardwareReset(){
  digitalWrite(PIN_PORb, LOW);
  delay(20); // 20ms
  digitalWrite(PIN_PORb, HIGH);
  delay(100); // 100ms
}
*/

// ================================================================
// Low-level SPI helpers
// ================================================================
static void spi_send_raw(const an_Byte* data, uint16_t len) {
  for (int i = 0; i < len; i++) {
    SPI.transfer(data[i]);
  }
}

// ================================================================
// Software reset
// an_GetResetData() returns {0xD5, 0x01, 0x6F}
// Your hardware needs 5 null preamble bytes before + 1 null after
// ================================================================
void fpaa_software_reset() {
  uint16_t count = 0;
  const an_Byte* data = an_GetResetData(an_FPAA1, &count);
  
  digitalWrite(SELb, LOW);
  for (int i = 0; i < 5; i++) SPI.transfer(0x00);  // preamble
  spi_send_raw(data, count);                         // {D5, 01, 6F}
  SPI.transfer(0x00);                                // trailing null
  digitalWrite(SELb, HIGH);
}

// ================================================================
// Primary configuration — programs the full FPAA circuit
// Payload starts with 0xD5, preceded by 5 null preamble bytes + 1 trailing null
// ================================================================
void fpaa_primary_config() {
  uint16_t count = 0;
  const an_Byte* data = an_GetPrimaryConfigData(an_FPAA1, &count);

  digitalWrite(SELb, LOW);
  for (int i = 0; i < 5; i++) SPI.transfer(0x00);  // preamble
  spi_send_raw(data, count);
  SPI.transfer(0x00);                                // trailing null
  digitalWrite(SELb, HIGH);
}

// ================================================================
// Send dynamic reconfiguration — call after any parameter update
// The reconfig packet already starts with 0xD5, no preamble needed + 1 trailing null
// ================================================================
void fpaa_send_reconfig() {
  uint16_t count = 0;
  const an_Byte* data = an_GetApexReconfigData(an_FPAA1, &count);

  if (count == 0) {
    //Serial.println("fpaa_send_reconfig: nothing to send.");
    return;
  }

  digitalWrite(SELb, LOW);
  spi_send_raw(data, count);
  SPI.transfer(0x00);                                // trailing null
  digitalWrite(SELb, HIGH);

  // Reset the buffer so it's clean for the next update
  an_ClearApexReconfigData(an_FPAA1);
}

// ================================================================
// Convenience wrapper — set filter by frequency, gain, Q
//
//   Fo  : corner frequency in kHz  (e.g. 1.0 = 1 kHz, 10.0 = 10 kHz)
//   G   : linear gain              (e.g. 1.0 = 0 dB, 2.0 = +6 dB)
//   Q   : quality factor           (e.g. 0.707 = Butterworth)
//
// After this call the new values are live on the chip.
// ================================================================
void fpaa_set_lowpass(double Fo_kHz, double G, double Q) {
  an_SetBQLowPassFilterI(an_FPAA1_FilterBiquad1, Fo_kHz, G, Q);
  fpaa_send_reconfig();
}

void setup() {
  // Initialize Serial
  Serial.begin(57600);

  // Initialize GPIO
  pinMode(PIN_PORb, OUTPUT); // hardware reset pin
  digitalWrite(PIN_PORb, HIGH);

  pinMode(SELb, OUTPUT); // set the SS pin as an output
  digitalWrite(SELb, HIGH);

  // Hardware SPI — UNO uses D11 MOSI, D12 MISO, D13 SCK
  SPI.begin();
  SPI.setBitOrder(MSBFIRST);
  SPI.setDataMode(SPI_MODE3);
  SPI.setClockDivider(SPI_CLOCK_DIV4);   // 16 MHz / 4 = 4 MHz

  delay(500);  // Allow SPI to stabilize

  // Must be called before any an_Set* functions
  an_InitializeApexReconfigData(an_FPAA1);

  // Program the FPAA
  fpaa_software_reset();
  fpaa_primary_config();

}

// ================================================================
// Loop — interactive Serial control of filter parameters
// ================================================================

// Current filter parameters (change these defaults to match your design)
static double current_Fo = 1.0;    // kHz
static double current_G  = 1.0;    // linear gain (1.0 = unity)
static double current_Q  = 0.707;  // Butterworth

void loop() {

  // Read and average multiple samples to reduce ADC jitter
  long adcSum = 0;
  for (int i = 0; i < POT_SAMPLES; i++) {
    adcSum += analogRead(A5);
  }
  int adcVal = adcSum / POT_SAMPLES;

  // UNO ADC is 10-bit (0-1024)
  // Map to frequency range 0.2 kHz to 10.0 kHz on a LOG scale.
  // Log scale feels much more natural for frequency sweeping —
  // linear would spend 98% of the pot on 5-10 kHz and barely
  // touch the low end.
  //
  // Formula: Fo = Fo_min * (Fo_max/Fo_min)^(adcVal/1024)
  //          which is: 0.2 * 50^(adcVal/1024)

  double Fo_min = 0.2;   // kHz
  double Fo_max = 10.0;  // kHz

  double Fo = Fo_min * pow((Fo_max / Fo_min), (double)adcVal / 1024.0);

  // Only update the FPAA if the frequency has changed enough
  // to be worth sending (avoids hammering the SPI bus with
  // tiny ADC fluctuations)
  static double last_Fo = 0.0;

  if (abs(Fo - last_Fo) > 0.02) {  // 20 Hz threshold
    last_Fo = Fo;
    fpaa_set_lowpass(Fo, current_G, current_Q);

    Serial.print("Fo = ");
    Serial.print(Fo * 1000.0, 1);  // print in Hz for readability
    Serial.print(" Hz  (ADC: ");
    Serial.print(adcVal);
    Serial.println(")");
  }

}
