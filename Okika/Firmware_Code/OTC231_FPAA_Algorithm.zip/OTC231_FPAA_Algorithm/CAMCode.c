#include "CAMCode.h"

/********************************************************************\
*                      AnadigmDesigner2 C Code                       *
*--------------------------------------------------------------------*
*                                                                    *
*  File:      CAMCode.c                                              *
*  Circuit:   ESP32_LPF.ad2                                          *
*  Generated: February 27, 2026:  01:09 AM                           *
*  Version:   2.8.0.10 -  (Standard) - Release                       *
*  Copyright: Copyright � 2002 Anadigm. All rights reserved.         *
*                                                                    *
\********************************************************************/

/*##################################################################*\
#                                                                    #
#                          FilterBiquad.cam                          #
#                                                                    #
\*##################################################################*/

 /*================================================================*\
 )                    Corner Frequency, Gain & Q                    (
 \*================================================================*/

  /*--------------------------------------------------------------*\
  |                      SetBQLowPassFilterI                       |
  +----------------------------------------------------------------+
  |                                                                |
  |  Description                                                   |
  |  ------------------------------                                |
  |  This function controls the corner frequency [kHz], gain, and  |
  |  Q of this filter.                                             |
  |                                                                |
  |                                                                |
  |  Instance Name       cam                 chip                  |
  |  ------------------------------------------------------------  |
  |  FilterBiquad1       an_FPAA1_FilterBiquad1 an_FPAA1           |
  |                                                                |
  \*--------------------------------------------------------------*/

     void an_SetBQLowPassFilterI(an_CAM cam, double Fo, double G, double Q)
     {
        static const double an_Pi = 3.1415926535897931;
        static const double an_TwoPi = 6.2831853071795862;
        static const int maxCA = 510;
        static const int maxCB = 510;
        
        int 	dC1, dC2, dC3, dC4, dCA, dCB;
        int CA1, CA2, CB1, CB2;
        int 	C1=0, C2=0, C3=0, C4=0, CA=0, CB=0;	//final low Q biquad values
        double	aFoa, aFoa2, aQ, aGlo;	//achieved parameter values
        
        long clocka = an_GetApexClockFrequency(cam, an_CAMClock_ClockA);
        double	FCdiv2PI = clocka/an_TwoPi;
        
        //Limits in this module are extremely complicated due to the interrelation of parameters
        
        double Glo = G;
        
        //Prewarp Fo (kHz) into Foa (Hz)
        double 	Wo  = 2.0*clocka*sin(an_Pi*Fo*1000.0/clocka);
        double  Foa = Wo/an_TwoPi;
        
        // calculate normalized capacitor values
        double nC2 = Wo / clocka;
        
                 //First calculate for low Q circuit
        double  err = 99999, bestErr1 = 9999;
        double bestErr2 = 9999;
        
        dCB = maxCB;
        
        while(dCB>0)
        {	if(Q<1.0)	
              //increase C3 to keep 1st stage DC gain less than total DC gain 
              dC3 = an_AdjustCap(nC2*dCB/Q);	
           else
              dC3 = an_AdjustCap(nC2*dCB);
           dC4 = an_AdjustCap(1.0*dCB*nC2/Q);
           
           if(Q<1.0)	
              //account for increased C3;  lower C2 will balance Fo in 1st stage
              aFoa2 = FCdiv2PI*dC3*Q/dCB;
           else
              aFoa2 = FCdiv2PI*dC3/dCB;
        
           aQ = 1.0*dCB*nC2/dC4;
           
           err = aQ/Q + Q/aQ + aFoa2/Foa + Foa/aFoa2;
        
           if (err < bestErr1)
           {
              bestErr1 = err;
              C3 = dC3;
              C4 = dC4;
              CB = dCB;
           }
              dCB--;
        }
        err = 99999;
        dCA = maxCA;
        while(dCA>0)
        {
           dC2 = an_AdjustCap(nC2*nC2*CB*dCA/C3);
           dC1 = an_AdjustCap(Glo * dC2);
        
           aGlo = 1.0* dC1/dC2;
           aFoa = FCdiv2PI*sqrt(1.0*dC2*C3/dCA/CB);
        
           err = aGlo/Glo + Glo/aGlo + aFoa/Foa + Foa/aFoa;
        
           if (err < bestErr2)
           {
              bestErr2 = err;
              C1 = dC1;
              C2 = dC2;
              CA = dCA;
           }
              dCA--;
        }
        
        CA1 = CA/2;
        CA2 = CA - CA1;
        
        CB1 = CB/2;
        CB2 = CB - CB1;
        
        an_SetCapValue(cam, an_AnadigmApex_FilterBiquad_C1, C1);
        an_SetCapValue(cam, an_AnadigmApex_FilterBiquad_C2, C2);
        an_SetCapValue(cam, an_AnadigmApex_FilterBiquad_C3, C3);
        an_SetCapValue(cam, an_AnadigmApex_FilterBiquad_C4, C4);
        an_SetCapValue(cam, an_AnadigmApex_FilterBiquad_CB1, CB1);
        an_SetCapValue(cam, an_AnadigmApex_FilterBiquad_CB2, CB2);
        an_SetCapValue(cam, an_AnadigmApex_FilterBiquad_CA1, CA1);
        an_SetCapValue(cam, an_AnadigmApex_FilterBiquad_CA2, CA2);
     }

 /*================================================================*\
 )                        LowPass Capacitors                        (
 \*================================================================*/

  /*--------------------------------------------------------------*\
  |                        SetBQLowPassCaps                        |
  +----------------------------------------------------------------+
  |                                                                |
  |  Description                                                   |
  |  ------------------------------                                |
  |  This function directly sets the capacitors for this CAM. It   |
  |  does not perform any validation of the data for correctness.  |
  |                                                                |
  |                                                                |
  |  Instance Name       cam                 chip                  |
  |  ------------------------------------------------------------  |
  |  FilterBiquad1       an_FPAA1_FilterBiquad1 an_FPAA1           |
  |                                                                |
  \*--------------------------------------------------------------*/

     void an_SetBQLowPassCaps(an_CAM cam, an_Byte C1, an_Byte C2, an_Byte C3, an_Byte C4, an_Byte CB1, an_Byte CB2, an_Byte CA1, an_Byte CA2)
     {
        an_SetCapValue(cam, an_AnadigmApex_FilterBiquad_C1, C1);
        an_SetCapValue(cam, an_AnadigmApex_FilterBiquad_C2, C2);
        an_SetCapValue(cam, an_AnadigmApex_FilterBiquad_C3, C3);
        an_SetCapValue(cam, an_AnadigmApex_FilterBiquad_C4, C4);
        an_SetCapValue(cam, an_AnadigmApex_FilterBiquad_CB1, CB1);
        an_SetCapValue(cam, an_AnadigmApex_FilterBiquad_CB2, CB2);
        an_SetCapValue(cam, an_AnadigmApex_FilterBiquad_CA1, CA1);
        an_SetCapValue(cam, an_AnadigmApex_FilterBiquad_CA2, CA2);
     }


