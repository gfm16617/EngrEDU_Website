/**
 * Okika SingleApex Board Emulator for Arduino UNO
 * ================================================
 * Emulates the Okika PIC firmware so that AnadigmDesigner2 (AD2) can
 * program an AN231E04 FPAA directly via an Arduino UNO.
 *
 * ── Wiring ───────────────────────────────────────────────────────────────
 *
 *   USB-UART adapter (any adapter with CTS/RTS exposed, e.g. CP2102/CH340):
 *     TX   →  D8   (SoftwareSerial RX)
 *     RX   ←  D9   (SoftwareSerial TX)
 *     GND  →  GND
 *     CTS  short-circuited to RTS on the adapter itself  ← CRITICAL
 *     DTR, VCC — leave unconnected
 *
 *   NOTE: Do NOT use the UNO's hardware Serial (pins 0/1) for AD2.
 *   The onboard USB chip ties DTR to RESET, so opening the port resets
 *   the UNO. The UNO's hardware serial also has no CTS/RTS pins.
 *
 *   SPI (to FPAA AN231E04):
 *     D13  SCK  →  FPAA SCLK   (pin 6)
 *     D11  MOSI →  FPAA SDIN   (pin 5)
 *     D12  MISO ←  FPAA SDOUT  (pin 4)
 *     D10  SS   →  FPAA nCS    (pin 3)
 *     D6   RST  →  FPAA nRESET (pin 2)
 *
 * ── Protocol ─────────────────────────────────────────────────────────────
 *
 *   AD2 opens/closes the port separately for each command session.
 *   '#' and 'T' must be responded to immediately on byte receipt —
 *   AD2 does not wait for ETX before reading the response.
 *
 *   Session 1 — Identity:
 *     AD2:  02 23          ← '#' (no ETX before response)
 *     UNO:  BOARD_STRING + 0x00
 *     AD2:  03             ← ETX sent after reading response
 *     AD2:  closes port
 *
 *   Session 2 — Chip ID:
 *     AD2:  02 54          ← 'T' (no ETX before response)
 *     UNO:  CHAIN_STRING + 0x00
 *     AD2:  03             ← ETX sent after reading response
 *     AD2:  closes port
 *
 *   Session 3 — Programming:
 *     AD2:  02 [5-byte length field + hex bitstream] 03
 *     UNO:  strips length field, decodes hex, software-resets FPAA,
 *           programs via SPI — no response
 *     AD2:  02 3F 03       ← '?' status query
 *     UNO:  '0'            ← success
 *     AD2:  closes port
 *
 *   Note: The 5-byte ASCII hex length field prepended by AD2 (e.g. "000EE"
 *   or "00072") encodes the number of ASCII hex characters that follow —
 *   i.e. twice the number of binary bytes in the bitstream payload.
 *   Example: "000EE" = 0xEE = 238 ASCII chars → 119 binary bytes.
 *   This field is stripped before hex decoding. The remaining hex data
 *   decodes to the raw FPAA bitstream including its own 5-byte null
 *   preamble and trailer as defined by the Anadigm SPI protocol.
 *
 * ── CTS/RTS loopback ─────────────────────────────────────────────────────
 *
 *   AD2 opens the port with hardware flow control enabled. Without CTS
 *   asserted, the USB-UART adapter will buffer but never transmit bytes.
 *   Shorting CTS to RTS on the adapter causes it to always see CTS
 *   asserted, allowing data to flow freely.
 *
 * ── RAM note ─────────────────────────────────────────────────────────────
 *
 *   The UNO has only 2 KB SRAM. The receive buffer is sized to fit the
 *   largest known AD2 bitstream (~500 hex chars = 250 bytes decoded).
 *   RX_BUF_SIZE covers the hex-encoded payload; BINARY_BUF_SIZE covers
 *   the decoded binary. Increase if you see corrupted programming.
 */

#include <Arduino.h>
#include <SoftwareSerial.h>
#include <SPI.h>

// ── AD2 serial port ───────────────────────────────────────────────────────
//#define AD2_SERIAL      Serial2
#define AD2_RX_PIN      8  // D8 ← USB-UART TX
#define AD2_TX_PIN      9  // D9 ← USB-UART RX
#define UART_BAUD       57600

SoftwareSerial AD2_SERIAL(AD2_RX_PIN, AD2_TX_PIN);

// ── SPI / FPAA pins ───────────────────────────────────────────────────────
#define SELb            10  // D10 → FPAA nCS    (hardware SS)
#define PIN_PORb        6  // D6  → FPAA nRESET
//#define ACLK            26

// UNO hardware SPI pins (fixed, cannot be changed):
//#define PIN_MOSI        17
//#define PIN_MISO        16
//#define PIN_SCK         5

// ── Protocol constants ────────────────────────────────────────────────────
#define STX             0x02
#define ETX             0x03
#define CMD_IDENTIFY    '#'   // 0x23 — reply with BOARD_STRING immediately
#define CMD_T           'T'   // 0x54 — reply with CHAIN_STRING immediately
#define CMD_STATUS      '?'   // 0x3F — reply with '0' after ETX

// ── Board identity strings (stored in flash to save RAM) ──────────────────
const char BOARD_STRING[] PROGMEM =
  "Okika SingleApex Board v1.0\nABK Version: 6.2.5\nRev Date: 25 Nov 2020\n";
const char CHAIN_STRING[] PROGMEM = "231E04|END";

// ── Bitstream length field ────────────────────────────────────────────────
// AD2 prepends a 5-byte ASCII hex length field to the bitstream payload.
// The value encodes the number of ASCII hex characters that follow
// (= 2 × binary byte count). E.g. "000EE" = 238 chars → 119 bytes.
// Strip this field before hex decoding — it is not part of the FPAA data.
#define BITSTREAM_PREFIX_LEN  5

// ── Receive buffer ────────────────────────────────────────────────────────
// Sized for the largest expected AD2 bitstream hex payload.
// 512 hex chars → 256 binary bytes, well within the AN231E04 bitstream size.
// Increase RX_BUF_SIZE if AD2 sends larger designs.
#define RX_BUF_SIZE     512
#define BINARY_BUF_SIZE (RX_BUF_SIZE / 2)

static uint8_t  rxBuf[RX_BUF_SIZE];
static uint16_t rxLen    = 0;
static bool     inPacket = false;

// ═════════════════════════════════════════════════════════════════════════
// Utility: print a PROGMEM string over SoftwareSerial
// ═════════════════════════════════════════════════════════════════════════

static void printProgmem(const char* str) {
  char c;
  while ((c = pgm_read_byte(str++)) != '\0') {
    AD2_SERIAL.write((uint8_t)c);
  }
}

// ═════════════════════════════════════════════════════════════════════════
// FPAA SPI programming
// ═════════════════════════════════════════════════════════════════════════

/**
 * Send the Anadigm software reset sequence over SPI.
 * Format: 5 null preamble bytes | 0xD5 0x01 0x6F | 1 null trailer
 */
static void fpaa_software_reset() {
  const uint8_t msg[9] = {0x00, 0x00, 0x00, 0x00, 0x00, 0xD5, 0x01, 0x6F, 0x00};
  digitalWrite(SELb, LOW);
  for (uint8_t i = 0; i < 9; i++) SPI.transfer(msg[i]);
  digitalWrite(SELb, HIGH);
  delay(5);
}

/**
 * Program the FPAA with a decoded binary bitstream.
 * The bitstream from AD2 (after stripping the prefix) already contains
 * the correct preamble and trailer — send it as-is.
 */
static void fpaa_program(const uint8_t* data, uint16_t len) {
  fpaa_software_reset();
  digitalWrite(SELb, LOW);
  for (uint16_t i = 0; i < len; i++) SPI.transfer(data[i]);
  digitalWrite(SELb, HIGH);
}

// ═════════════════════════════════════════════════════════════════════════
// ASCII-hex decoder
// ═════════════════════════════════════════════════════════════════════════

static int hex_decode(const uint8_t* hex, uint16_t hexLen, uint8_t* out) {
  if (hexLen == 0 || hexLen % 2 != 0) return -1;
  for (size_t i = 0; i < hexLen; i += 2) {
    uint8_t hi = hex[i];
    uint8_t lo = hex[i + 1];
    if      (hi >= 'a' && hi <= 'f') hi = hi - 'a' + 10;
    else if (hi >= 'A' && hi <= 'F') hi = hi - 'A' + 10;
    else if (hi >= '0' && hi <= '9') hi = hi - '0';
    else return -1;
    if      (lo >= 'a' && lo <= 'f') lo = lo - 'a' + 10;
    else if (lo >= 'A' && lo <= 'F') lo = lo - 'A' + 10;
    else if (lo >= '0' && lo <= '9') lo = lo - '0';
    else return -1;
    out[i / 2] = (hi << 4) | lo;
  }
  return (int16_t)(hexLen / 2);
}

// ═════════════════════════════════════════════════════════════════════════
// Protocol command handlers
// ═════════════════════════════════════════════════════════════════════════

// '#' — send board version banner
static void handle_identify() {
  //AD2_SERIAL.print(BOARD_STRING);
  printProgmem(BOARD_STRING);
  AD2_SERIAL.write((uint8_t)0x00);
}

// 'T' — send FPAA chip ID chain
static void handle_T() {
  //AD2_SERIAL.print(CHAIN_STRING);
  printProgmem(CHAIN_STRING);
  AD2_SERIAL.write((uint8_t)0x00);
}

// '?' — send status byte
static void handle_status() {
  AD2_SERIAL.write('0');
}

// bitstream — strip prefix, decode hex, program FPAA
static void handle_bitstream(const uint8_t* payload, uint16_t len) {
  static uint8_t binary[RX_BUF_SIZE / 2];

  // Strip the 5-byte ASCII hex length field prepended by AD2.
  // This encodes the ASCII char count (2× binary bytes), not used for
  // decoding — the remaining hex string is decoded directly.
  if (len <= BITSTREAM_PREFIX_LEN) return;

  const uint8_t* hexData = payload + BITSTREAM_PREFIX_LEN;
  uint16_t       hexLen  = len - BITSTREAM_PREFIX_LEN;

  // Guard against overflow of the binary buffer
  if (hexLen > (uint16_t)(BINARY_BUF_SIZE * 2)) return;

  int16_t binLen = hex_decode(hexData, hexLen, binary);
  if (binLen < 0) return;

  fpaa_program(binary, (size_t)binLen);
}

static void process_packet(const uint8_t* payload, uint16_t len) {
  if (len == 0) return;
  if (len == 1 && payload[0] == CMD_STATUS) handle_status();
  else                                            handle_bitstream(payload, len);
}

// ═════════════════════════════════════════════════════════════════════════
// Setup
// ═════════════════════════════════════════════════════════════════════════

void setup() {
  // SoftwareSerial for AD2 communication
  AD2_SERIAL.begin(UART_BAUD);

  // FPAA control pins
  pinMode(PIN_PORb, OUTPUT);
  digitalWrite(PIN_PORb, HIGH);
  pinMode(SELb, OUTPUT);
  digitalWrite(SELb, HIGH);

  // Hardware SPI — UNO uses D11 MOSI, D12 MISO, D13 SCK
  SPI.begin();
  SPI.setBitOrder(MSBFIRST);
  SPI.setDataMode(SPI_MODE3);
  SPI.setClockDivider(SPI_CLOCK_DIV4);   // 16 MHz / 4 = 4 MHz
}

// ═════════════════════════════════════════════════════════════════════════
// Main loop
// ═════════════════════════════════════════════════════════════════════════

void loop() {
  while (AD2_SERIAL.available()) {
    uint8_t b = (uint8_t)AD2_SERIAL.read();

    // '#' and 'T' are responded to immediately on byte receipt.
    // AD2 reads the response before sending ETX, so we must not wait
    // for ETX before dispatching these commands.
    if (inPacket && b == CMD_IDENTIFY) {
      inPacket = false;
      rxLen    = 0;
      handle_identify();
      return;
    }

    if (inPacket && b == CMD_T) {
      inPacket = false;
      rxLen    = 0;
      handle_T();
      return;
    }

    // Bitstream and '?' use full STX/ETX framing
    if (b == STX) {
      rxLen    = 0;
      inPacket = true;

    } else if (b == ETX && inPacket) {
      inPacket = false;
      process_packet(rxBuf, rxLen);
      rxLen = 0;

    } else if (inPacket) {
      if (rxLen < RX_BUF_SIZE) {
        rxBuf[rxLen++] = b;
      } else {
        inPacket = false;
        rxLen    = 0;
      }
    }
  }
}
