#include <SPI.h>
#include "LPF_Config.h"

#define SELb 10

void resetConfig(){
  // State Reconfiguration
  byte msg[9] = {0, 0, 0, 0, 0, 213, 1, 111, 0};

  digitalWrite(SELb, LOW);
  for(int i=0; i<9; i++){  
    SPI.transfer(msg[i]);
  }
  digitalWrite(SELb, HIGH);
}

void sendConfig(){
  // Send Configuration
  digitalWrite(SELb, LOW);
  for(int i=0; i<(sizeof(fpaa_state)); i++){
    SPI.transfer(fpaa_state[i]);
  }
  digitalWrite(SELb, HIGH);
}

void setup() {
  // Initialize SPI
  pinMode(SELb, OUTPUT); // set the SS pin as an output

  SPI.begin();
  SPI.setBitOrder(MSBFIRST);
  SPI.setDataMode(SPI_MODE3);
  SPI.setClockDivider(SPI_CLOCK_DIV2);
  
  delay(50);  // Allow SPI to stabilize

  resetConfig();
  sendConfig();
}

void loop() {
  // idle
}
