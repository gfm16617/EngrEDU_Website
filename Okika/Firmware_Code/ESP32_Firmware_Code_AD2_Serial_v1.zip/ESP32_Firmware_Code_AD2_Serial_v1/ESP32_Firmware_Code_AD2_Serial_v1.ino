/**
 * Okika SingleApex Board Emulator for ESP32
 * ==========================================
 * Emulates the Okika PIC firmware so that AnadigmDesigner2 (AD2) can
 * program an AN231E04 FPAA directly via an ESP32.
 *
 * ── Wiring ───────────────────────────────────────────────────────────────
 *
 *   USB-UART adapter (any adapter with CTS/RTS exposed):
 *     TX   →  ESP32 GPIO25  (Serial2 RX)
 *     RX   ←  ESP32 GPIO14  (Serial2 TX)
 *     GND  →  ESP32 GND
 *     CTS  short-circuited to RTS on the adapter itself
 *     DTR, VCC — leave unconnected
 *
 *   SPI (to FPAA):
 *     GPIO5   SCK  →  FPAA SCLK   (pin 6)
 *     GPIO17  MOSI →  FPAA SDIN   (pin 5)
 *     GPIO16  MISO ←  FPAA SDOUT  (pin 4)
 *     GPIO18  CS   →  FPAA nCS    (pin 3)
 *     GPIO27  RST  →  FPAA nRESET (pin 2)
 *     GPIO26  ACLK →  FPAA CLKE   (pin 1)  16 MHz via LEDC
 *
 * ── Protocol ─────────────────────────────────────────────────────────────
 *
 *   AD2 opens/closes the port separately for each command session.
 *   '#' and 'T' must be responded to immediately on byte receipt —
 *   AD2 does not wait for ETX before reading the response.
 *
 *   Session 1 — Identity:
 *     AD2:   02 23          ← '#' (no ETX before response)
 *     ESP32: BOARD_STRING + 0x00
 *     AD2:   03             ← ETX sent after reading response
 *     AD2:   closes port
 *
 *   Session 2 — Chip ID:
 *     AD2:   02 54          ← 'T' (no ETX before response)
 *     ESP32: CHAIN_STRING + 0x00
 *     AD2:   03             ← ETX sent after reading response
 *     AD2:   closes port
 *
 *   Session 3 — Programming:
 *     AD2:   02 [5-byte length field + hex bitstream] 03
 *     ESP32: strips length field, decodes hex, software-resets FPAA,
 *            programs via SPI — no response
 *     AD2:   02 3F 03       ← '?' status query
 *     ESP32: '0'            ← success
 *     AD2:   closes port
 *
 *   Note: The 5-byte ASCII hex length field prepended by AD2 (e.g. "000EE"
 *   or "00072") encodes the number of ASCII hex characters that follow —
 *   i.e. twice the number of binary bytes in the bitstream payload.
 *   Example: "000EE" = 0xEE = 238 ASCII chars → 119 binary bytes.
 *   This field is stripped before hex decoding. The remaining hex data
 *   decodes to the raw FPAA bitstream including its own 5-byte null
 *   preamble and trailer as defined by the Anadigm SPI protocol.
 *   The length field could be used to validate payload completeness
 *   but is not strictly required for correct operation.
 *
 * ── CTS/RTS loopback ─────────────────────────────────────────────────────
 *
 *   AD2 opens the port with hardware flow control enabled. Without CTS
 *   asserted, the USB-UART adapter will buffer but never transmit bytes.
 *   Shorting CTS to RTS on the adapter causes it to always see CTS
 *   asserted, allowing data to flow freely.
 */

#include <Arduino.h>
#include <SPI.h>

// ── AD2 serial port ───────────────────────────────────────────────────────
#define AD2_SERIAL      Serial2
#define AD2_RX_PIN      25
#define AD2_TX_PIN      14
#define UART_BAUD       57600

// ── SPI / FPAA pins ───────────────────────────────────────────────────────
#define SELb            18
#define PIN_MOSI        17
#define PIN_MISO        16
#define PIN_SCK         5
#define PIN_PORb        27
#define ACLK            26

// ── Protocol constants ────────────────────────────────────────────────────
#define STX             0x02
#define ETX             0x03
#define CMD_IDENTIFY    '#'   // 0x23 — reply with BOARD_STRING immediately
#define CMD_T           'T'   // 0x54 — reply with CHAIN_STRING immediately
#define CMD_STATUS      '?'   // 0x3F — reply with '0' after ETX

// ── Board identity strings ────────────────────────────────────────────────
#define BOARD_STRING    "Okika SingleApex Board v1.0\nABK Version: 6.2.5\nRev Date: 25 Nov 2020\n"
#define FPAA_ID         "231E04"
#define CHAIN_STRING    FPAA_ID "|END"

// ── Bitstream length field ────────────────────────────────────────────────
// AD2 prepends a 5-byte ASCII hex length field to the bitstream payload.
// The value encodes the number of ASCII hex characters that follow
// (= 2 × binary byte count). E.g. "000EE" = 238 chars → 119 bytes.
// Strip this field before hex decoding — it is not part of the FPAA data.
#define BITSTREAM_PREFIX_LEN  5

// ── Receive buffer ────────────────────────────────────────────────────────
#define RX_BUF_SIZE     4096
static uint8_t  rxBuf[RX_BUF_SIZE];
static uint16_t rxLen    = 0;
static bool     inPacket = false;

// ═════════════════════════════════════════════════════════════════════════
// FPAA SPI programming
// ═════════════════════════════════════════════════════════════════════════

/**
 * Send the Anadigm software reset sequence over SPI.
 * Format: 5 null preamble bytes | 0xD5 0x01 0x6F | 1 null trailer
 */
static void fpaa_software_reset() {
  byte msg[9] = {0x00, 0x00, 0x00, 0x00, 0x00, 0xD5, 0x01, 0x6F, 0x00};
  digitalWrite(SELb, LOW);
  for (int i = 0; i < 9; i++) SPI.transfer(msg[i]);
  digitalWrite(SELb, HIGH);
  delay(5);
}

/**
 * Program the FPAA with a decoded binary bitstream.
 * The bitstream from AD2 (after stripping the prefix) already contains
 * the correct preamble and trailer — send it as-is.
 */
static void fpaa_program(const uint8_t* data, size_t len) {
  fpaa_software_reset();
  digitalWrite(SELb, LOW);
  for (size_t i = 0; i < len; i++) SPI.transfer(data[i]);
  digitalWrite(SELb, HIGH);
}

// ═════════════════════════════════════════════════════════════════════════
// ASCII-hex decoder
// ═════════════════════════════════════════════════════════════════════════

static int hex_decode(const uint8_t* hex, size_t hexLen, uint8_t* out) {
  if (hexLen == 0 || hexLen % 2 != 0) return -1;
  for (size_t i = 0; i < hexLen; i += 2) {
    uint8_t hi = hex[i];
    uint8_t lo = hex[i + 1];
    if      (hi >= 'a' && hi <= 'f') hi = hi - 'a' + 10;
    else if (hi >= 'A' && hi <= 'F') hi = hi - 'A' + 10;
    else if (hi >= '0' && hi <= '9') hi = hi - '0';
    else return -1;
    if      (lo >= 'a' && lo <= 'f') lo = lo - 'a' + 10;
    else if (lo >= 'A' && lo <= 'F') lo = lo - 'A' + 10;
    else if (lo >= '0' && lo <= '9') lo = lo - '0';
    else return -1;
    out[i / 2] = (hi << 4) | lo;
  }
  return (int)(hexLen / 2);
}

// ═════════════════════════════════════════════════════════════════════════
// Protocol command handlers
// ═════════════════════════════════════════════════════════════════════════

// '#' — send board version banner
static void handle_identify() {
  AD2_SERIAL.print(BOARD_STRING);
  AD2_SERIAL.write((uint8_t)0x00);
}

// 'T' — send FPAA chip ID chain
static void handle_T() {
  AD2_SERIAL.print(CHAIN_STRING);
  AD2_SERIAL.write((uint8_t)0x00);
}

// '?' — send status byte
static void handle_status() {
  AD2_SERIAL.write('0');
}

// bitstream — strip prefix, decode hex, program FPAA
static void handle_bitstream(const uint8_t* payload, size_t len) {
  static uint8_t binary[RX_BUF_SIZE / 2];

  // Strip the 5-byte ASCII hex length field prepended by AD2.
  // This encodes the ASCII char count (2× binary bytes), not used for
  // decoding — the remaining hex string is decoded directly.
  if (len <= BITSTREAM_PREFIX_LEN) return;

  const uint8_t* hexData = payload + BITSTREAM_PREFIX_LEN;
  size_t         hexLen  = len - BITSTREAM_PREFIX_LEN;

  int binLen = hex_decode(hexData, hexLen, binary);
  if (binLen < 0) return;

  fpaa_program(binary, (size_t)binLen);
}

static void process_packet(const uint8_t* payload, size_t len) {
  if (len == 0) return;
  if      (len == 1 && payload[0] == CMD_STATUS) handle_status();
  else                                            handle_bitstream(payload, len);
}

// ═════════════════════════════════════════════════════════════════════════
// Setup
// ═════════════════════════════════════════════════════════════════════════

void setup() {
  AD2_SERIAL.begin(UART_BAUD, SERIAL_8N1, AD2_RX_PIN, AD2_TX_PIN);

  pinMode(ACLK, OUTPUT);
  ledcAttach(ACLK, 16000000, 1);
  ledcWrite(ACLK, 1);

  pinMode(PIN_PORb, OUTPUT);
  digitalWrite(PIN_PORb, HIGH);
  pinMode(SELb, OUTPUT);
  digitalWrite(SELb, HIGH);

  SPI.begin(PIN_SCK, PIN_MISO, PIN_MOSI, SELb);
  SPI.setBitOrder(MSBFIRST);
  SPI.setDataMode(SPI_MODE3);
}

// ═════════════════════════════════════════════════════════════════════════
// Main loop
// ═════════════════════════════════════════════════════════════════════════

void loop() {
  while (AD2_SERIAL.available()) {
    uint8_t b = AD2_SERIAL.read();

    // '#' and 'T' are responded to immediately on byte receipt.
    // AD2 reads the response before sending ETX, so we must not wait
    // for ETX before dispatching these commands.
    if (inPacket && b == CMD_IDENTIFY) {
      inPacket = false;
      rxLen    = 0;
      handle_identify();
      return;
    }

    if (inPacket && b == CMD_T) {
      inPacket = false;
      rxLen    = 0;
      handle_T();
      return;
    }

    // Bitstream and '?' use full STX/ETX framing
    if (b == STX) {
      rxLen    = 0;
      inPacket = true;

    } else if (b == ETX && inPacket) {
      inPacket = false;
      process_packet(rxBuf, rxLen);
      rxLen = 0;

    } else if (inPacket) {
      if (rxLen < RX_BUF_SIZE) {
        rxBuf[rxLen++] = b;
      } else {
        inPacket = false;
        rxLen    = 0;
      }
    }
  }
}
