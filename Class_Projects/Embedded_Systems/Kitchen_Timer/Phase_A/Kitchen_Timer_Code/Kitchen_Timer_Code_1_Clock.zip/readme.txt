
Clock_v1
- counts in seconds
- button 1 increments counter
- button 2 resets counter and turns clock timer off

Clock_v2
- counts in minutes
- adjust 7-seg to turn on decimal point
- Pins were adjusted according to PCB Design (DIG1..4 and DS/SH_CP)
- fully functional



