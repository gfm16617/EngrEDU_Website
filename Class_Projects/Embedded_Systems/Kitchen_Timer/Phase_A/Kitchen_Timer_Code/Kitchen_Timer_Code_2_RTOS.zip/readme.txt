

FreeRTOS_Example_1
- set 3 tasks running in parallel
  - Serial task
  - Blink Red LED Task
  - Blink Green LED Task

FreeRTOS_Example_2
- test the use of queues to change information between tasks

Clock_FreeRTOS
- Implementatino of Clock_v2 with FreeRTOS

