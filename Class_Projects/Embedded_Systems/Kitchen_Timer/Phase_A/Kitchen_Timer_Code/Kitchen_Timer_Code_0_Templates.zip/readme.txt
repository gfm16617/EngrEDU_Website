
NoConcurrency
- 4 tasks running in a polling method (not efficient at all)

Simple_Interrupt
- buttons have their own interrutps
- 7-seg code runs on the main thread

Interrupt_Driven
- all tasks have their own interrupt routine

Interrupt_Pooling_Driven
- a combination between pooling and interrupt driven
- all tasks have their own interrupt routine but they use isr flags to communicate with main thread

SimpleCounter
- buttons used to increment a counter that is displayed on the 7-seg
- debounce problems



